//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

1 + 1

var steps = 1000
var incremental = 1
var multiplicative = 1
for i in 1...steps {
    incremental = incremental + i
    multiplicative = multiplicative * i
}